chained [![Travis CI Status](https://travis-ci.org/getlantern/chained.svg?branch=master)](https://travis-ci.org/getlantern/chained)&nbsp;[![Coverage Status](https://coveralls.io/repos/getlantern/chained/badge.png)](https://coveralls.io/r/getlantern/chained)&nbsp;[![GoDoc](https://godoc.org/github.com/getlantern/chained?status.png)](http://godoc.org/github.com/getlantern/chained)
==========
To install:

`go get github.com/getlantern/chained`

For docs:

`godoc github.com/getlantern/chained`
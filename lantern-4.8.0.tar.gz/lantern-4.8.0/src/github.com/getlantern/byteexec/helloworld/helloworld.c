//C hello world example
#include <stdio.h>
 
int main()
{
  printf("Hello world\n");
  return 0;
}

package byteexec

const linefeed = "\r\n"

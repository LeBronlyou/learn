'use strict';

angular.module('feeds', ['feeds-services', 'feeds-directives']);